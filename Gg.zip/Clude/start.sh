#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

python -m pip install --disable-pip-version-check -q -r requirements.txt

exec python run_bot.py
